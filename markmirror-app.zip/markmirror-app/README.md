# MarkMirror: ResultRadar Rush

Exam result lookup and batch analytics dashboard. Node.js server, JSON data store, vanilla JS frontend with Chart.js.

## Run
1. Install Node.js 16 or newer (no npm packages are needed).
2. In this folder run: `node server.js`  (or `npm start`)
3. Open http://localhost:3000

`data/students.json` is included (200 students, batches 2021 and 2022). To rebuild it: `node generate-data.js`.
Try hall tickets 22CSE104, 22ECE110, 22IT125. An internet connection is needed for Chart.js and Google Fonts.

## API
- GET /api/meta
- GET /api/result/:hallTicket
- GET /api/analytics?batch=2022
- GET /api/toppers?branch=CSE
- GET /api/compare
- GET /api/reeval?ht=22CSE104&codes=CS203,CS204

SGPA = sum(credits * grade points) / sum(credits). Only raw marks are stored; grades, SGPA and CGPA are computed by the server.
