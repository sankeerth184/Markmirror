// MarkMirror ResultRadar: REST API + static file server. No npm packages needed.
const http = require("http"), fs = require("fs"), path = require("path"), url = require("url");
const DATA = path.join(__dirname, "data", "students.json"), PUBLIC = path.join(__dirname, "public");
if (!fs.existsSync(DATA)) { console.error("data/students.json not found. Run: node generate-data.js"); process.exit(1); }
const db = JSON.parse(fs.readFileSync(DATA, "utf8"));
const GP = { O: 10, "A+": 9, A: 8, "B+": 7, B: 6, C: 5, F: 0 };
const grade = t => t >= 90 ? "O" : t >= 80 ? "A+" : t >= 70 ? "A" : t >= 60 ? "B+" : t >= 50 ? "B" : t >= 40 ? "C" : "F";
const r2 = x => Math.round(x * 100) / 100;
const subs = db.subjects, BRANCHES = [...new Set(db.batches.flatMap(b => b.students.map(s => s.branch)))];
const BINS = ["Below 6", "6-7", "7-8", "8-9", "9-10"], binOf = c => c < 6 ? 0 : c < 7 ? 1 : c < 8 ? 2 : c < 9 ? 3 : 4;

// credit-weighted GPA = sum(credits * points) / sum(credits)
function compute(s) {
  let pts = 0, cr = 0, earned = 0;
  const rows = s.marks.map(m => {
    const sub = subs.find(x => x.code === m.code), total = m.internal + m.external, g = grade(total);
    pts += sub.credits * GP[g]; cr += sub.credits; if (g !== "F") earned += sub.credits;
    return { code: sub.code, name: sub.name, credits: sub.credits, internal: m.internal, external: m.external, total, grade: g, points: GP[g], pass: g !== "F" };
  });
  const sgpa = pts / cr, hist = s.history.concat(sgpa);
  return { ...s, rows, sgpa, credits: cr, earned, allPass: rows.every(r => r.pass), cgpa: hist.reduce((a, b) => a + b, 0) / hist.length };
}
const ALL = db.batches.flatMap(b => b.students.map(compute)), byHT = new Map(ALL.map(s => [s.ht, s]));
const years = db.batches.map(b => b.year).sort(), latest = years[years.length - 1];
// pre-compute rankings and per-group averages once at start-up
const groups = {};
ALL.forEach(s => (groups[s.batch + s.branch] = groups[s.batch + s.branch] || []).push(s));
Object.values(groups).forEach(g => {
  g.sort((a, b) => b.sgpa - a.sgpa || b.earned - a.earned);
  g.avg = subs.map((_, i) => Math.round(g.reduce((t, s) => t + s.rows[i].total, 0) / g.length));
});

function Phi(z) { const t = 1 / (1 + .2316419 * Math.abs(z)), d = .3989423 * Math.exp(-z * z / 2), p = d * t * (.3193815 + t * (-.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274)))); return z > 0 ? 1 - p : p; }
function analytics(year) {
  const st = ALL.filter(s => s.batch === year), n = st.length;
  const passes = subs.map((_, i) => st.filter(s => s.rows[i].pass).length);
  const meanC = st.reduce((a, s) => a + s.cgpa, 0) / n, sd = Math.sqrt(st.reduce((a, s) => a + (s.cgpa - meanC) ** 2, 0) / n);
  const counts = [0, 0, 0, 0, 0]; st.forEach(s => counts[binOf(s.cgpa)]++);
  const edges = [-1e9, 6, 7, 8, 9, 1e9], bell = BINS.map((_, i) => r2(n * (Phi((edges[i + 1] - meanC) / sd) - Phi((edges[i] - meanC) / sd))));
  const grades = {}; Object.keys(GP).forEach(g => grades[g] = 0); st.forEach(s => s.rows.forEach(r => grades[r.grade]++));
  const subjects = subs.map((sub, i) => {
    // difficulty index uses failure history across ALL batches: 60% fail rate + 40% grade-point shortfall
    const fail = ALL.filter(s => !s.rows[i].pass).length / ALL.length * 100, avgAll = ALL.reduce((a, s) => a + s.rows[i].points, 0) / ALL.length;
    return { code: sub.code, name: sub.name, passPct: r2(passes[i] / n * 100), failPct: r2(100 - passes[i] / n * 100), avgPoints: r2(st.reduce((a, s) => a + s.rows[i].points, 0) / n), historicFailPct: r2(fail), difficulty: r2(fail * .6 + (1 - avgAll / 10) * 100 * .4) };
  });
  const low = subjects.slice().sort((a, b) => a.passPct - b.passPct)[0];
  return { batch: year, kpis: { total: n, passAllPct: r2(st.filter(s => s.allPass).length / n * 100), meanCgpa: r2(meanC), lowest: { name: low.name, passPct: low.passPct } }, subjects, grades, bins: { labels: BINS, counts, bell } };
}
function compare() {
  return { batches: years.map(y => { const st = ALL.filter(s => s.batch === y), c = [0, 0, 0, 0, 0]; st.forEach(s => c[binOf(s.sgpa)]++);
    return { year: y, total: st.length, avgSgpa: r2(st.reduce((a, s) => a + s.sgpa, 0) / st.length), passAllPct: r2(st.filter(s => s.allPass).length / st.length * 100), topSgpa: r2(Math.max(...st.map(s => s.sgpa))), distinctions: st.filter(s => s.allPass && s.sgpa >= 8.5).length, binsPct: c.map(v => r2(v / st.length * 100)) }; }), binLabels: BINS };
}
const HT = /^\d{2}[A-Z]{2,4}\d{3}$/;
function result(k) {
  const s = byHT.get(k); if (!s) return null;
  const g = groups[s.batch + s.branch], below = g.filter(x => x.sgpa < s.sgpa).length;
  return { ht: s.ht, name: s.name, branch: s.branch, batch: s.batch, rows: s.rows, sgpa: r2(s.sgpa), cgpa: r2(s.cgpa), credits: s.credits, earned: s.earned, allPass: s.allPass, distinction: s.allPass && s.sgpa >= 8.5,
    rank: g.indexOf(s) + 1, branchSize: g.length, topPercent: Math.max(1, 100 - Math.round(below / g.length * 100)), history: s.history, branchAvg: g.avg, meta: db.meta };
}
const send = (res, code, obj) => { res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }); res.end(JSON.stringify(obj)); };
const MIME = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".json": "application/json", ".ico": "image/x-icon" };

http.createServer((req, res) => {
  const u = url.parse(req.url, true), p = decodeURIComponent(u.pathname);
  if (req.method !== "GET") return send(res, 405, { error: "Method not allowed" });
  if (p === "/api/meta") return send(res, 200, { meta: db.meta, subjects: subs, branches: BRANCHES, batches: years, latest, hallTickets: ALL.map(s => s.ht), examples: ["22CSE104", ALL.find(s => s.batch === latest && s.branch === "ECE").ht.replace(/\d+$/, "110"), ALL.find(s => s.batch === latest && s.branch === "IT").ht.replace(/\d+$/, "125")] });
  if (p.startsWith("/api/result/")) { const k = p.slice(12).trim().toUpperCase();
    if (!HT.test(k)) return send(res, 400, { error: "Invalid hall ticket format. Example: 22CSE104" });
    const r = result(k); return r ? send(res, 200, r) : send(res, 404, { error: "No result found for hall ticket " + k }); }
  if (p === "/api/analytics") { const y = +u.query.batch || latest; return years.includes(y) ? send(res, 200, analytics(y)) : send(res, 404, { error: "Unknown batch" }); }
  if (p === "/api/toppers") { const b = String(u.query.branch || BRANCHES[0]).toUpperCase(), y = +u.query.batch || latest, g = groups[y + b];
    return g ? send(res, 200, { batch: y, branch: b, toppers: g.slice(0, 10).map((s, i) => ({ rank: i + 1, ht: s.ht, name: s.name, sgpa: r2(s.sgpa), earned: s.earned })) }) : send(res, 404, { error: "Unknown branch" }); }
  if (p === "/api/compare") return send(res, 200, compare());
  if (p === "/api/reeval") { const s = byHT.get(String(u.query.ht || "").toUpperCase()); if (!s) return send(res, 404, { error: "Unknown hall ticket" });
    const codes = [...new Set(String(u.query.codes || "").split(",").filter(Boolean))];
    if (codes.some(c => !subs.find(x => x.code === c))) return send(res, 400, { error: "Unknown subject code" });
    return send(res, 200, { ht: s.ht, codes, count: codes.length, feePerSubject: db.meta.reevalFee, fee: codes.length * db.meta.reevalFee }); }
  if (p.startsWith("/api/")) return send(res, 404, { error: "Unknown endpoint" });
  const f = path.join(PUBLIC, p === "/" ? "index.html" : p);
  if (!f.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end("Forbidden"); }
  fs.readFile(f, (e, buf) => { if (e) { res.writeHead(404); return res.end("Not found"); } res.writeHead(200, { "Content-Type": MIME[path.extname(f)] || "application/octet-stream" }); res.end(buf); });
}).listen(process.env.PORT || 3000, () => console.log("MarkMirror running at http://localhost:" + (process.env.PORT || 3000)));
