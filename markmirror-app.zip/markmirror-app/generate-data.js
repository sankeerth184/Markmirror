// Builds data/students.json: two batches of 100 students with internal and external marks.
// Only raw marks are stored. Grades, SGPA and CGPA are computed by the server.
const fs = require("fs"), path = require("path");
const subjects = [
  { code: "MA201", name: "Mathematics", credits: 4, bias: 0 },
  { code: "CS202", name: "DBMS", credits: 4, bias: -2 },
  { code: "CS203", name: "Operating Systems", credits: 3, bias: -24 },
  { code: "CS204", name: "Computer Networks", credits: 3, bias: -4 },
  { code: "CS205", name: "Software Engineering", credits: 3, bias: 2 },
  { code: "CS206", name: "AI Lab", credits: 3, bias: 8 }
];
let seed = 2024;
const rnd = () => (seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296;
const gauss = () => (rnd() + rnd() + rnd() + rnd() - 2) * 1.6;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const FN = ["Aarav","Ananya","Karthik","Sneha","Rohit","Divya","Sai","Meera","Arjun","Pooja","Vikram","Lavanya","Nikhil","Harini","Rahul","Keerthi","Varun","Sowmya","Manoj","Priya"];
const LN = ["Reddy","Sharma","Rao","Kumar","Naidu","Patel","Iyer","Goud","Verma","Chowdary"];
const split = t => { const lo = Math.max(0, t - 60), hi = Math.min(40, t); const i = clamp(Math.round(t * 0.4 + gauss() * 1.5), lo, hi); return { internal: i, external: t - i }; };
function makeBatch(year, mean) {
  const yy = String(year).slice(2), counts = { CSE: 40, ECE: 30, IT: 30 }, out = [];
  for (const branch of Object.keys(counts)) for (let i = 0; i < counts[branch]; i++) {
    const ab = mean + gauss() * 13;
    out.push({
      ht: yy + branch + (101 + i),
      name: FN[Math.floor(rnd() * FN.length)] + " " + LN[Math.floor(rnd() * LN.length)],
      branch, batch: year,
      history: [0, 1, 2].map(() => +clamp(ab / 10 + 0.4 + gauss() * 0.5, 5, 9.9).toFixed(2)),
      marks: subjects.map(s => ({ code: s.code, ...split(clamp(Math.round(ab + s.bias + gauss() * 9), 18, 99)) }))
    });
  }
  return out;
}
const b22 = makeBatch(2022, 68), b21 = makeBatch(2021, 64);
const demo = b22.find(s => s.ht === "22CSE104");          // fixed record: SGPA 8.85 (distinction)
demo.name = "Ananya Reddy"; demo.history = [8.6, 8.9, 9.0];
demo.marks = [86, 84, 75, 88, 76, 93].map((t, i) => ({ code: subjects[i].code, internal: Math.round(t * 0.4), external: t - Math.round(t * 0.4) }));
const db = {
  meta: { university: "MarkMirror University", exam: "B.Tech Regular Examinations", semester: "IV", passMark: 40, reevalFee: 500, currency: "INR" },
  subjects: subjects.map(({ code, name, credits }) => ({ code, name, credits })),
  batches: [{ year: 2021, students: b21 }, { year: 2022, students: b22 }]
};
fs.mkdirSync(path.join(__dirname, "data"), { recursive: true });
fs.writeFileSync(path.join(__dirname, "data", "students.json"), JSON.stringify(db));
console.log("Wrote data/students.json:", b21.length + b22.length, "students");
