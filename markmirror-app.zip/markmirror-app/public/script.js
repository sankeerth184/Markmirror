(function(){
var $=function(id){return document.getElementById(id)};
var HAS_CHART=typeof Chart!=="undefined";
function mk(id,cfg){var el=$(id);if(!HAS_CHART){el.parentNode.innerHTML='<p class="err">Charts could not load. Check your internet connection, because Chart.js is loaded from a CDN.</p>';return null}return new Chart(el,cfg)}
function api(p){return fetch(p).then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.error||"Request failed");return j},function(){throw new Error("Server error")})})}
function esc(t){return String(t).replace(/[&<>"']/g,function(c){return"&#"+c.charCodeAt(0)+";"})}
function f2(x){return Number(x).toFixed(2)}
var out=$("out"),err=$("err"),ht=$("ht"),analyticsP=null,drawn={},meta=null;
function getA(){if(!analyticsP)analyticsP=api("/api/analytics").catch(function(e){analyticsP=null;throw e});return analyticsP}
function fail(el,e){el.innerHTML='<p class="err">'+esc(e.message)+'</p>'}

/* tabs */
var tabs=[].slice.call(document.querySelectorAll("nav button"));
tabs.forEach(function(b){b.onclick=function(){
 tabs.forEach(function(x){x.setAttribute("aria-selected",x===b)});
 [].forEach.call(document.querySelectorAll("main>section"),function(s){s.hidden=s.id!==b.dataset.t});
 var t=b.dataset.t;if(t==="analytics"&&!drawn.a)drawA();if(t==="compare"&&!drawn.c)drawC();if(t==="tools"&&!drawn.t)drawT()}});
document.querySelector("nav").onkeydown=function(e){var i=tabs.indexOf(document.activeElement);if(i<0||(e.key!=="ArrowRight"&&e.key!=="ArrowLeft"))return;var n=tabs[(i+(e.key==="ArrowRight"?1:tabs.length-1))%tabs.length];n.focus();n.click()};

/* start-up: hall ticket list, example chips, branch buttons */
api("/api/meta").then(function(m){meta=m;
 $("hts").innerHTML=m.hallTickets.map(function(h){return'<option value="'+h+'">'}).join("");
 m.examples.forEach(function(h){var c=document.createElement("span");c.className="chip";c.textContent=h;c.tabIndex=0;c.onclick=function(){ht.value=h;show()};c.onkeydown=function(e){if(e.key==="Enter")c.click()};$("chips").appendChild(c)});
 m.branches.forEach(function(b){var x=document.createElement("button");x.textContent=b;x.onclick=function(){lb(b)};$("bt").appendChild(x)});lb(m.branches[0])
}).catch(function(e){err.textContent="Cannot reach the server: "+e.message});

/* result lookup */
function show(){var k=ht.value.trim().toUpperCase();err.textContent="";out.innerHTML="";if(!k){err.textContent="Enter a hall ticket number.";return}
 api("/api/result/"+encodeURIComponent(k)).then(render).catch(function(e){err.textContent=e.message})}
function render(r){
 var rows=r.rows.map(function(x){return"<tr><td>"+x.code+"</td><td>"+esc(x.name)+"</td><td class='n'>"+x.credits+"</td><td class='n'>"+x.internal+"/40</td><td class='n'>"+x.external+"/60</td><td class='n'>"+x.total+"</td><td class='"+(x.pass?"":"F")+"'>"+x.grade+"</td><td class='n'>"+x.points+"</td></tr>"}).join("");
 out.innerHTML='<div id="sheet"><h3>Examination Result: Semester '+esc(r.meta.semester)+'</h3><p class="sub">'+esc(r.meta.exam)+', Provisional Marksheet</p>'+
 '<div class="meta"><div>Name: <b>'+esc(r.name)+'</b></div><div>Hall ticket: <b>'+r.ht+'</b></div><div>Branch: <b>'+esc(r.branch)+'</b></div><div>Branch rank: <b>'+r.rank+' of '+r.branchSize+'</b></div><div>Standing: <b>Top '+r.topPercent+'% of branch</b></div><div>Batch: <b>'+r.batch+'</b></div></div>'+
 '<div class="tablewrap"><table><thead><tr><th>Code</th><th>Subject</th><th class="n">Credits</th><th class="n">Internal</th><th class="n">External</th><th class="n">Total</th><th>Grade</th><th class="n">Points</th></tr></thead><tbody>'+rows+'</tbody></table></div>'+
 '<div class="result"><span>SGPA: '+f2(r.sgpa)+'</span><span>CGPA: '+f2(r.cgpa)+'</span><span>Credits earned: '+r.earned+'/'+r.credits+'</span><span>'+(r.allPass?"PASS":"FAIL")+(r.distinction?' <span class="badge">Distinction</span>':'')+'</span></div><p class="scale">Grade scale: O (90 and above) = 10, A+ (80) = 9, A (70) = 8, B+ (60) = 7, B (50) = 6, C (40) = 5, F (below 40) = 0. Pass mark: '+r.meta.passMark+'.</p></div>'+
 '<div class="row noprint" style="justify-content:center;margin-bottom:20px"><button class="btn" id="pr" type="button">Print or save as PDF</button></div>'+
 '<div class="card noprint"><h2>SGPA trend</h2><div class="canvasbox" style="height:240px"><canvas id="cTr"></canvas></div></div><div class="card noprint"><h2>You vs branch average</h2><div class="canvasbox" style="height:260px"><canvas id="cVs"></canvas></div></div>';
 $("pr").onclick=function(){window.print()};
 mk("cTr",{type:"line",data:{labels:r.history.map(function(_,i){return"Sem "+(i+1)}).concat(["Sem "+(r.history.length+1)]),datasets:[{label:"SGPA",data:r.history.concat([r.sgpa]),borderColor:"#0e6e8c",backgroundColor:"#0e6e8c",tension:.3}]},options:{maintainAspectRatio:false,scales:{y:{min:4,max:10}}}});
 mk("cVs",{type:"bar",data:{labels:r.rows.map(function(x){return x.name}),datasets:[{label:"You",data:r.rows.map(function(x){return x.total}),backgroundColor:"#0e6e8c"},{label:"Branch average",data:r.branchAvg,backgroundColor:"#e0a100"}]},options:{maintainAspectRatio:false,scales:{y:{max:100,title:{display:true,text:"Marks out of 100"}}}}});
 out.scrollIntoView({behavior:"smooth",block:"start"})}
$("go").onclick=show;ht.onkeydown=function(e){if(e.key==="Enter")show()};

/* batch analytics */
function drawA(){getA().then(function(a){drawn.a=true;var k=a.kpis;
 $("kpis").innerHTML=[[k.total,"students in batch "+a.batch],[Math.round(k.passAllPct)+"%","passed every subject"],[k.lowest.name+" ("+Math.round(k.lowest.passPct)+"%)","lowest pass rate; batch mean CGPA "+f2(k.meanCgpa)]].map(function(x){return'<div class="card stat"><b>'+esc(x[0])+'</b><span>'+esc(x[1])+'</span></div>'}).join("");
 mk("cPass",{type:"bar",data:{labels:a.subjects.map(function(s){return s.name}),datasets:[{label:"Pass %",data:a.subjects.map(function(s){return s.passPct}),backgroundColor:a.subjects.map(function(s){return s.passPct===k.lowest.passPct?"#c0392b":"#0e6e8c"})},{label:"Fail %",data:a.subjects.map(function(s){return s.failPct}),backgroundColor:"#e0a100"}]},options:{maintainAspectRatio:false,scales:{y:{max:100,title:{display:true,text:"% of students"}}}}});
 var gk=Object.keys(a.grades);
 mk("cGrade",{type:"doughnut",data:{labels:gk,datasets:[{data:gk.map(function(g){return a.grades[g]}),backgroundColor:["#14213d","#0e6e8c","#2fa4a9","#8bc5a3","#e0a100","#e8884a","#c0392b"]}]},options:{maintainAspectRatio:false}});
 mk("cHist",{type:"bar",data:{labels:a.bins.labels,datasets:[{label:"Students",data:a.bins.counts,backgroundColor:"#0e6e8c",categoryPercentage:1,barPercentage:.95},{type:"line",label:"Normal curve",data:a.bins.bell,borderColor:"#e0a100",backgroundColor:"#e0a100",tension:.4,pointRadius:3}]},options:{maintainAspectRatio:false,plugins:{legend:{display:true}},scales:{y:{title:{display:true,text:"Students"}},x:{title:{display:true,text:"CGPA range"}}}}})
}).catch(function(e){fail($("kpis"),e)})}

/* toppers */
function lb(b){[].forEach.call($("bt").querySelectorAll("button"),function(x){x.setAttribute("aria-pressed",x.textContent===b)});
 var m=["\ud83e\udd47","\ud83e\udd48","\ud83e\udd49"];
 api("/api/toppers?branch="+encodeURIComponent(b)).then(function(d){$("board").innerHTML=d.toppers.map(function(s,i){return'<li><span class="medal">'+(m[i]||s.rank)+'</span><span><b>'+esc(s.name)+'</b><br><small style="color:var(--mut)">'+s.ht+'</small></span><span>SGPA <b>'+f2(s.sgpa)+'</b></span><span style="color:var(--mut)">'+s.earned+' credits</span></li>'}).join("")}).catch(function(e){fail($("board"),e)})}

/* batch comparison */
function drawC(){api("/api/compare").then(function(d){drawn.c=true;var B=d.batches,f=B[0],l=B[B.length-1];
 function row(t,k,u){var x=f[k],y=l[k],c=y-x;return'<tr><td>'+t+'</td><td class="n">'+x.toFixed(u)+'</td><td class="n">'+y.toFixed(u)+'</td><td class="n" style="color:var(--'+(c>=0?'ok':'bad')+')">'+(c>=0?'+':'')+c.toFixed(u)+'</td></tr>'}
 $("cmpT").innerHTML='<thead><tr><th>Metric</th><th class="n">'+f.year+' batch</th><th class="n">'+l.year+' batch</th><th class="n">Change</th></tr></thead><tbody>'+row("Average SGPA","avgSgpa",2)+row("Passed all subjects (%)","passAllPct",0)+row("Highest SGPA","topSgpa",2)+row("Distinctions (SGPA 8.5+)","distinctions",0)+'</tbody>';
 mk("cCmp2",{type:"bar",data:{labels:d.binLabels,datasets:B.map(function(b,i){return{label:String(b.year),data:b.binsPct,backgroundColor:i?"#0e6e8c":"#e0a100"}})},options:{maintainAspectRatio:false,scales:{y:{title:{display:true,text:"% of students"}},x:{title:{display:true,text:"SGPA range"}}}}})
}).catch(function(e){fail($("cmpT"),e)})}

/* re-evaluation and difficulty */
function drawT(){getA().then(function(a){drawn.t=true;
 $("diff").innerHTML='<thead><tr><th>Subject</th><th class="n">Historic fail rate</th><th class="n">Avg grade point</th><th class="n">Difficulty</th></tr></thead><tbody>'+a.subjects.slice().sort(function(x,y){return y.difficulty-x.difficulty}).map(function(s){return'<tr><td>'+esc(s.name)+'</td><td class="n">'+s.historicFailPct.toFixed(0)+'%</td><td class="n">'+f2(s.avgPoints)+'</td><td class="n"><b>'+s.difficulty.toFixed(0)+'</b></td></tr>'}).join("")+'</tbody>'}).catch(function(e){fail($("diff"),e)})}
var rev=$("rev");
function upd(k){var codes=[].map.call(rev.querySelectorAll(".rc:checked"),function(c){return c.value});
 if(!codes.length){$("tot").textContent="\u20b90";return}
 api("/api/reeval?ht="+k+"&codes="+codes.join(",")).then(function(r){$("tot").textContent="\u20b9"+r.fee}).catch(function(e){$("tot").textContent=e.message})}
$("rgo").onclick=function(){var k=$("rht").value.trim().toUpperCase();
 api("/api/result/"+encodeURIComponent(k)).then(function(r){
  rev.innerHTML='<p style="margin-top:0">'+esc(r.name)+'. Tick the papers you want rechecked (\u20b9'+r.meta.reevalFee+' per subject).</p>'+r.rows.map(function(x){return'<label style="display:block;padding:4px 0"><input type="checkbox" class="rc" value="'+x.code+'" style="text-transform:none;min-width:auto;margin-right:8px"> '+esc(x.name)+' <span style="color:var(--mut)">(grade '+x.grade+')</span></label>'}).join("")+'<p><b>Total fee: <span id="tot">\u20b90</span></b></p>';
  [].forEach.call(rev.querySelectorAll(".rc"),function(c){c.onchange=function(){upd(r.ht)}})
 }).catch(function(e){fail(rev,e)})};
})();
